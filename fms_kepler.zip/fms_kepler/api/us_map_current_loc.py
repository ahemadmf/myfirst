import pandas as pd
import json
from flask import Flask, jsonify
from keplergl import KeplerGl

def us_map_current_loc_html(config_file, session_id, user_latitude, user_longitude):


    my_dict = {
        'Latitude': {
            0: user_latitude
        },
        'Longitude': {
            0: user_longitude
        },
        'icon': {
            0: "profile"
        }
    }

    us_edges = config_file['us_edges']


    my_dict = pd.DataFrame(my_dict)
    my_edge = pd.DataFrame(us_edges)

    with open(config_file['config']['us_current_loc'], 'r') as f:
        config = f.read()
    config = json.loads(config)
    us_map = KeplerGl(height=1000, data={'data': my_dict, 'data1': my_edge}, config=config)

    # us_map.save_to_html(file_name=config_file['html']['html_root'] + session_id + '_' + config_file['html']['us_current_loc'], read_only=True)
    us_map.save_to_html(file_name=config_file['html']['html_root'] + session_id + '_' + config_file['html']['us_current_loc'])
    return  {"message": config_file['export_msg']}