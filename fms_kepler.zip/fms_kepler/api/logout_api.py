import os, glob

def clear_html(config_file, session_id):
    for filename in glob.glob(config_file['html']['html_root'] + session_id + '_*'):
        os.remove(filename)
    return {"message": config_file['remove_html']}
