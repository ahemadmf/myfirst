import csv
import os
import sys
from collections import defaultdict
from math import asin, cos, radians, sin, sqrt
from operator import itemgetter
import json
from api import tiny_url, utils
from keplergl import KeplerGl

import pandas as pd

def haversine(lon1, lat1, lon2, lat2):
    """
    Calculate the great circle distance between two points
    on the earth (specified in decimal degrees)
    """
    # convert decimal degrees to radians
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])

    # haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 3956 # Radius of earth in miles.
    return c * r

def top_five_spare_loc(src_lat, src_lon, top_five_spare_location_file, vendor, partnumber):
    # Read a file to fetch column details ( Latitude and Longitude ) -> dest_lat aand dest_long respectively
    columns = defaultdict(list) # each value in each column is appended to a list
    with open('csv/FMS_SPARES.csv') as f , open(top_five_spare_location_file, 'w', newline='') as file:
        reader = csv.DictReader(f) # read rows into a dictionary format
        for row in reader: # read a row as {column1: value1, column2: value2,...}
            for (k,v) in row.items(): # go over each column name and value
                columns[k].append(v) # append the value into the appropriate list
                                     # based on column name k

        distance = []
        src_latitude = []
        src_longitude = []
        vendor_list = []
        partnumber_list = []
        infractions_list = []
        percentage_list = []
        shelf_list = []
        bin_list = []
        url = []
        if len(columns['Latitude']) == len(columns['Longitude']):

            length = len(columns['Latitude'])

            for n in range(length):
                if (columns['VENDOR'][n] == vendor) and (columns['PARTNUMBER'][n] == partnumber):

                    dest_lat = float(columns['Latitude'][n])
                    dest_long = float(columns['Longitude'][n])

                    # Get the distance in miles using haversine formula.
                    dist = haversine(src_lon, src_lat, dest_long, dest_lat)
                    map_link = "https://www.google.com/maps/dir/" + str(src_lat) + "," + str(src_lon) + "/" + str(dest_lat) + "," + str(dest_long)
                    final_url = tiny_url.make_tiny(map_link)

                    distance.append(dist)
                    src_latitude.append(src_lat)
                    src_longitude.append(src_lon)                    
                    vendor_list.append(vendor)
                    partnumber_list.append(partnumber)
                    infractions_list.append(columns['INFRACTIONS'][n])
                    percentage_list.append(columns['PERCENTAGE'][n])
                    bin_list.append(columns['BIN'][n])
                    shelf_list.append(columns['SHELF'][n])
                    url.append(final_url)

                else:
                    pass
        else:
            return {"error": "Incorrect data"}

        # Row heading for new file - line graph
        row_list = [["src_Latitude", "src_Longitude", "LATITUDE", "LONGITUDE",
                     "SPARE_CLLI_CODE", "SPARE_COUNT", "VENDOR", "PART NUMBER", "INFRACTIONS", "PERCENTAGE",
                     "SHELF", "BIN", "DISTANCE", "GOOGLE MAPS"]]

        # Add by column
        l = [src_latitude, src_longitude, columns['Latitude'], columns['Longitude'], columns['SPARE_CLLI_CODE'],
             columns['SPARE_COUNT'], vendor_list, partnumber_list, infractions_list, percentage_list,
             shelf_list, bin_list, distance, url]

        # Write a new file for line graph
        writer = csv.writer(file)
        writer.writerows(row_list)
        writer.writerows(zip(*l))
        file.close()



def sort_top_five(top_five_spare_location_file):

    data = pd.read_csv(top_five_spare_location_file)
    data = data.sort_values(['DISTANCE'])
    data = data.head(n=5)
    os.remove(top_five_spare_location_file)
    data.to_csv(top_five_spare_location_file)

    with open('csv/sample.csv','r') as csvinput:
        with open('csv/output.csv', 'w') as csvoutput:
            writer = csv.writer(csvoutput, lineterminator='\n')
            reader = csv.reader(csvinput)
            data = []
            dest_lat = ''
            dest_lon = ''
            count = 0
            for item in reader:
                if count == 0:
                    print("count 0")
                    count = count + 1
                elif count == 1:
                    print("count 1")
                    dest_lat = item[3]
                    dest_lon = item[4]
                    count = count + 1
                else:
                    print("count --> ", count)
                    if item[3] == dest_lat and item[4] == dest_lon:
                        print("same loc")
                    else:
                        print("diff loc")
                    count = count + 1








def route_html(config_file, session_id, lat, lon, partnumber, vendor):
    top_five_spare_location_file = "csv/route_map.csv"

    top_five_spare_loc(lat, lon, top_five_spare_location_file, vendor, partnumber)
    sort_top_five(top_five_spare_location_file)

    current_loc_dict = {
        'source_Latitude': {
            0: lat
        },
        'source_Longitude': {
            0: lon
        },
        'icon': {
            0: 'profile'
        }
    }
    
    us_edges = config_file['us_edges']

    dict_data = pd.read_csv(top_five_spare_location_file)
    my_edge = pd.DataFrame(us_edges)


    current_loc = pd.DataFrame(current_loc_dict)
    with open('config/route_csv.json', 'r') as f:
        config = f.read()
    config = json.loads(config)
    route_map = KeplerGl(height=500, data={'data1': dict_data, 'data2': current_loc, 'us_edges': my_edge}, config=config)

    # route_map.save_to_html(file_name=config_file['html']['html_root'] + session_id + '_' + config_file['html']['route_map'], read_only=True)
    route_map.save_to_html(file_name=config_file['html']['html_root'] + session_id + '_' + config_file['html']['route_map'])

    return {"message": config_file['export_msg']}

 

def heat_map_html(config_file, session_id, lat, lon, partnumber, vendor):
    top_five_spare_location_file = "csv/heat_map.csv"

    top_five_spare_loc(lat, lon, top_five_spare_location_file, vendor, partnumber)

    current_loc_dict = {
        'source_Latitude': {
            0: float(lat)
        },
        'source_Longitude': {
            0: float(lon)
        },
        'icon': {
            0: 'profile'
        }
    }


    current_loc = pd.DataFrame(current_loc_dict)
    dict_data = pd.read_csv(top_five_spare_location_file)
    
    with open('config/heat_map_csv.json', 'r') as f:
        config = f.read()
    config = json.loads(config)

        
    heat_map = KeplerGl(height=500, data={'data1': dict_data, 'data2': current_loc}, config=config)

    heat_map.save_to_html(file_name=config_file['html']['html_root'] + session_id + '_' + config_file['html']['heat_map'])
    # heat_map.save_to_html(file_name=config_file['html']['html_root'] + session_id + '_' + config_file['html']['heat_map'], read_only=True)

    return {"message": config_file['export_msg']}
