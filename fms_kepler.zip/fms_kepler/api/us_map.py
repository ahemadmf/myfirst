# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %%
from keplergl import KeplerGl
import json

def us_map_html(config_file, session_id):
    with open(config_file['config']['heat_map'], 'r') as f:
        config = f.read()
    config = json.loads(config)
    us_map = KeplerGl(height=1000, config=config)

    us_map.save_to_html(file_name= config_file['html']['html_root'] + session_id + '_' + config_file['html']['us_map'], read_only=True)
    return {"message": config_file['export_msg']}
# %%


