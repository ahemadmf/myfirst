import os
from math import asin, cos, radians, sin, sqrt

import cx_Oracle


def haversine(lon1, lat1, lon2, lat2):
    """
    Calculate the great circle distance between two points
    on the earth (specified in decimal degrees)
    """
    # convert decimal degrees to radians
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])

    # haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 3956 # Radius of earth in miles.
    return c * r

def oracle_connection(config_file, connect):
    try:
        # Path for instant client - Connection for database
        LOCATION = config_file['oracle']['path']
        os.environ["PATH"] = LOCATION + ";" + os.environ["PATH"]

        con = cx_Oracle.connect(connect)
        return "Connected", con
    except cx_Oracle.DatabaseError as err:
        return "Failure", err
