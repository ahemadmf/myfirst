from fastapi import FastAPI
import uvicorn
from api import (us_map, us_map_current_loc, logout_api, route_csv)
import json
from starlette.middleware.cors import CORSMiddleware

app = FastAPI(title='Find my spare API - Using Kepler.gl',
description='API that will allow users to Generate HTML file.')

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def read_config():
    try:
        with open('config/config.json', 'r') as readConfig:
            config = json.load(readConfig)
            readConfig.close()
    except FileNotFoundError:
        config = {"error": "Config File Not Found"}
    return config


@app.get("/")
async def home():
    return {"message": "Welcome to FMS API"}

@app.get("/us_map/{session_id}")
async def get_us_map(session_id: str):
    config_file = read_config()
    return us_map.us_map_html(config_file, session_id)

@app.get("/us_map/{session_id}/{lat}/{lon}")
async def get_us_map_current_loc(session_id: str, lat: float, lon: float):
    config_file = read_config()
    return us_map_current_loc.us_map_current_loc_html(config_file, session_id, lat, lon)

@app.get('/heat_map/{session_id}/{lat}/{lon}/{partnumber}/{vendor}')
def get_heat_map(session_id: str, lat: float, lon: float, partnumber: str, vendor: str):
    config_file = read_config()
    return route_csv.heat_map_html(config_file, session_id, lat, lon, partnumber, vendor)

@app.get('/route/{session_id}/{lat}/{lon}/{partnumber}/{vendor}')
def get_route(session_id: str, lat: float, lon: float, partnumber: str, vendor: str):
    config_file = read_config()
    return route_csv.route_html(config_file, session_id, lat, lon, partnumber, vendor)

@app.get("/session_expired/{session_id}")
async def session_expired(session_id: str):
    config_file = read_config()
    return logout_api.clear_html(config_file, session_id)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8086)